#! /bin/bash
timestamp(){
  date "+%Y-%m-%d %H:%M:%S [INFO] "
}
myidt='                           '
/home/ec2-user/get-stackinfo.sh

echo "$(timestamp)Installer coordinator initiated."
localip=`sed -n '2p' self.info`
nodelayer=`cat /home/ec2-user/role.info`

#echo $localip
#echo $nodelayer
applayer_asg="ApplicationServerGroup"
dblayer_asg="DatabaseServerGroup"
selayer_asg="SearchEngineServerGroup"

if [[ $nodelayer = *"$applayer_asg"* ]]; then
  echo "$myidt""My private IP "$localip" is in app cluster: "`cat /home/ec2-user/app.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'`
  echo "$myidt""In db layer, the cluster has: "`cat /home/ec2-user/db.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'`
  echo "$myidt""In se layer, the cluster has: "`cat /home/ec2-user/se.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'`
  echo "$(timestamp)Installer coordinator launches Application Installer."
  ## REPLACE WITH INSTALLER COMMAND FOR APPLICATION ##
  echo "Application Install Completed" > "/tmp/app.node.status"

elif [[ $nodelayer = *"$dblayer_asg"* ]]; then
  echo "$myidt""My private IP $(localip) is in db cluster: "`cat /home/ec2-user/db.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'` 
  echo "$myidt""In app layer, the cluster has: "`cat /home/ec2-user/app.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'`
  echo "$myidt""In se layer, the cluster has: "`cat /home/ec2-user/se.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'`
  echo "$(timestamp)Installer coordinator launches Database Installer."
  ## REPLACE WITH INSTALLER COMMAND FOR DATABASE ##
  echo "Database Install Completed" > "/tmp/db.node.status"

elif [[ $nodelayer = *"$selayer_asg"* ]]; then
  echo "$myidt""My private IP $(localip) is in se cluster: "`cat /home/ec2-user/se.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'` 
  echo "$myidt""In app layer, the cluster has: "`cat /home/ec2-user/app.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'`
  echo "$myidt""In db layer, the cluster has: "`cat /home/ec2-user/db.layer.info | awk -F"," 'FNR==1 {next} { print $2 }' | tr '\n' ',' | sed 's/,$/\n/'`
  echo "$(timestamp)Installer coordinator launches Search Engine Installer.."
  ## REPLACE WITH INSTALLER COMMAND FOR SEARCHENGINE ##
  echo "SearchEngine Install Completed" > "/tmp/se.node.status"
else
  echo "$(timestamp)Installer coordinator does not find this node belong to any layer."
  echo "Node identity is unknown. Nothing is Installed." > "/tmp/node.status"
fi

echo "$(timestamp)Installer coordinator completed."
