#!/bin/bash
stack_ready=-1

if [ $# -ne 1 ]; then
  echo $stack_ready
  exit
fi

asg_name=$1
cli_res=`aws autoscaling describe-auto-scaling-groups`
#cli_res=`cat example-describe-auto-scaling-groups.json`


max_size=`echo "$cli_res"| jq '.AutoScalingGroups[]|select(.AutoScalingGroupName|contains("'$asg_name'"))|.MaxSize'`

min_size=`echo "$cli_res"| jq '.AutoScalingGroups[]|select(.AutoScalingGroupName|contains("'$asg_name'"))|.MinSize'`

desired_size=`echo "$cli_res"| jq '.AutoScalingGroups[]|select(.AutoScalingGroupName|contains("'$asg_name'"))|.DesiredCapacity'`

total_inst_cnt=`echo "$cli_res"| jq '.AutoScalingGroups[]|select(.AutoScalingGroupName|contains("'$asg_name'"))|.Instances|length'`

active_inst_cnt=`echo "$cli_res"| jq '.AutoScalingGroups[]|select(.AutoScalingGroupName|contains("'$asg_name'"))|.Instances[]|select(.HealthStatus=="Healthy" and .LifecycleState=="InService")' | jq -s length`

if [[ -z "$max_size" ]] || [[ -z "$min_size" ]] || [[ -z "$desired_size" ]] || [[ -z "$total_inst_cnt" ]] || [[ -z "$active_inst_cnt" ]];
then
  echo $stack_ready
  exit
fi

#echo $max_size,$min_size,$desired_size,$total_inst_cnt,$active_inst_cnt

if [[ "$active_inst_cnt" -eq "$total_inst_cnt" ]] && [[ "$active_inst_cnt" -ge "$min_size" ]] && [[ "$active_inst_cnt" -le "$max_size" ]];
then
  stack_ready=0
fi

echo $stack_ready

