#! /bin/bash

max_retry=60

num_retry=0
until [ $(./is-asg-stable.sh "ApplicationServerGroup") -eq 0 ] && [ $(./is-asg-stable.sh "DatabaseServerGroup") -eq 0 ] && [ $(./is-asg-stable.sh "SearchEngineServerGroup") -eq 0 ]; 
do
  echo `basename "$0"`": Some layers are not ready will retry in 5 seconds"
  let "num_retry++"
  sleep 5s
  if [ $num_retry -gt $max_retry ];
  then
    echo `basename "$0"`": It has taken too long to retry and I gave up. Please investigate or increase number of retry."
    exit
  fi
done

echo `basename "$0"`": collecting node info for each layer, exporting result to info files."

# the describe-auto-scaling-group should also deliver the same result using corresponding jq parsing.
cli_res=`aws autoscaling describe-auto-scaling-instances`
AppInstIDs=`echo "$cli_res" | jq -r '.AutoScalingInstances[] | select(.AutoScalingGroupName|contains("ApplicationServerGroup"))|.InstanceId'`

DBInstIDs=`echo "$cli_res" | jq -r '.AutoScalingInstances[] | select(.AutoScalingGroupName|contains("DatabaseServerGroup"))|.InstanceId'`

SEInstIDs=`echo "$cli_res" | jq -r '.AutoScalingInstances[] | select(.AutoScalingGroupName|contains("SearchEngineServerGroup"))|.InstanceId'`

if [ -f ERROR.info ] ; then
  rm ERROR.info
fi

if [[ -z $AppInstIDs ]] | [[ -z $DBInstIDs ]] | [[ -z $SEInstIDs ]]; then
   echo "cli result might contain incorrect format of information.. Please investigate." > ERROR.info
fi

echo "AppInstID,PrivateIP" > app.layer.info
for instID in $AppInstIDs; do
   echo $instID,`./get-ip-by-instance-id.sh $instID` >> app.layer.info
done

echo "DBInstID,PrivateIP" > db.layer.info
for instID in $DBInstIDs; do
   echo $instID,`./get-ip-by-instance-id.sh $instID` >> db.layer.info
done

echo "SEInstID,PrivateIP" > se.layer.info
for instID in $SEInstIDs; do
   echo $instID,`./get-ip-by-instance-id.sh $instID` >> se.layer.info
done

