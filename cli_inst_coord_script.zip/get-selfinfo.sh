#! /bin/bash
MyInstID=`curl -s http://169.254.169.254/latest/meta-data/instance-id`
MyPrvIp=`curl -s http://169.254.169.254/latest/meta-data/local-ipv4`
#MyGroupCmd="aws autoscaling describe-auto-scaling-instances | jq -r "\'".AutoScalingInstances[]|select (.InstanceId==\""$MyInstID"\")|.AutoScalingGroupName"\'

echo $MyInstID > self.info
echo $MyPrvIp >> self.info
#eval "$MyGroupCmd" >> self.info
